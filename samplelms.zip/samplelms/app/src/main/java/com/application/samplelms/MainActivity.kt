package com.application.samplelms


import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize buttons
        val btnAdmin = findViewById<Button>(R.id.btnAdmin)
        val btnVendor = findViewById<Button>(R.id.btnVendor)
        val btnUser = findViewById<Button>(R.id.btnUser)

        // Set click listeners
        btnAdmin.setOnClickListener { // Navigate to com.application.samplelms.com.application.samplelms.com.application.samplelms.MainActivity2
            startActivity(Intent(this@MainActivity, MainActivity2::class.java))
        }
        btnVendor.setOnClickListener { // Navigate to com.application.samplelms.com.application.samplelms.com.application.samplelms.MainActivity2
            startActivity(Intent(this@MainActivity, MainActivity3::class.java))
        }
        btnUser.setOnClickListener { // Navigate to com.application.samplelms.com.application.samplelms.com.application.samplelms.MainActivity2
            startActivity(Intent(this@MainActivity, MainActivity4::class.java))
        }
    }
}
