package com.application.samplelms

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class admin : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        // Get the TextViews
        val maintainVendorTextView: TextView = findViewById(R.id.maintainVendorTextView)
        val maintainUserTextView: TextView = findViewById(R.id.maintainUserTextView)

        // Set click listeners for Maintain Vendor and Maintain User TextViews
        maintainVendorTextView.setOnClickListener {
            // Navigate to the desired activity for maintaining vendors
            startActivity(Intent(this, Maintainvendor::class.java))
        }

        maintainUserTextView.setOnClickListener {
            // Navigate to the desired activity for maintaining users
            startActivity(Intent(this, Maintainuser::class.java))
        }
    }
}
