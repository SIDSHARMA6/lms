package com.application.samplelms

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity7 : AppCompatActivity() {

    private lateinit var nameEditText: EditText
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var signUpButton: Button

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main7)

        nameEditText = findViewById(R.id.nameEditText)
        emailEditText = findViewById(R.id.emailEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        signUpButton = findViewById(R.id.loginButton)

        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        signUpButton.setOnClickListener {
            val name = nameEditText.text.toString().trim()
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                // Save data to SharedPreferences
                saveData(name, email, password)

                // Navigate to the desired activity after sign up
                // startActivity(Intent(this, DesiredActivity::class.java))
                // Finish current activity after navigation
                // finish()
           // Navigate to com.application.samplelms.com.application.samplelms.com.application.samplelms.MainActivity2
                    startActivity(Intent(this@MainActivity7, MainActivity::class.java))

            }
        }

        loadData() // Load data from SharedPreferences
    }

    private fun saveData(name: String, email: String, password: String) {
        val editor = sharedPreferences.edit()
        editor.putString("NAME", name)
        editor.putString("EMAIL", email)
        editor.putString("PASSWORD", password)
        editor.apply()
    }

    private fun loadData() {
        val name = sharedPreferences.getString("NAME", "")
        val email = sharedPreferences.getString("EMAIL", "")
        val password = sharedPreferences.getString("PASSWORD", "")

        nameEditText.setText(name)
        emailEditText.setText(email)
        passwordEditText.setText(password)
    }
}
