package com.application

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.application.samplelms.R

class cart : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)
    }
}